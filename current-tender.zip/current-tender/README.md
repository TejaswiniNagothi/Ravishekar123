# CURRENT TENDER

A Pen created on CodePen.io. Original URL: [https://codepen.io/Nagothi-Tejaswini/pen/XWvLZdy](https://codepen.io/Nagothi-Tejaswini/pen/XWvLZdy).

